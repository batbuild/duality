﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Duality;

namespace Release
{
	[Serializable]
    public class YourCustomComponentType : Component
    {

    }
}
