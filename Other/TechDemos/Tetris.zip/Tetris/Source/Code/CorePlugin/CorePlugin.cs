﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Duality;

namespace Tetris
{
	/// <summary>
	/// Defines a Duality core plugin.
	/// </summary>
    public class TetrisCorePlugin : CorePlugin {}
}
